package com.talentcerebrumhrms.datatype;

/**
 * Created by saransh on 19-10-2016.
 */

public class HolidayDatatype {

    private String name, date, day;

    public void setName(String name) {
        this.name = name;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getName() {
        return this.name;
    }

    public String getDate() {
        return this.date;
    }

    public String getDay() {
        return this.day;
    }
}
