package com.talentcerebrumhrms.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import com.talentcerebrumhrms.datatype.TimesheetDataType;

import java.util.ArrayList;

/**
 * Created by Harshit on 06-Jul-17.
 */

public class OnGoingInterviewAdapter extends BaseAdapter {

    public OnGoingInterviewAdapter(Context mcontext, ArrayList<TimesheetDataType> list, String status) {
    }

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return null;
    }
}
