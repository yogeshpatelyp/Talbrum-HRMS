package com.talentcerebrumhrms.utils;

/**
 * Created by saransh on 15-11-2016.
 */

public interface DrawerButtonListerner {
    void hamburgerEnabled(boolean value);
}
