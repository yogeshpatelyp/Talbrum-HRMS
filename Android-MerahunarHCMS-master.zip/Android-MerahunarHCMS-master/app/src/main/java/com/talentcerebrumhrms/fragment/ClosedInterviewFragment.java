package com.talentcerebrumhrms.fragment;

import android.support.v4.app.Fragment;

/**
 * Created by Harshit on 06-Jul-17.
 */

public class ClosedInterviewFragment extends Fragment {
}
