package com.talentcerebrumhrms.utils;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * Created by saransh on 13/11/17.
 */

@GlideModule
public class MyAppGlideModule extends AppGlideModule {


}
