package com.talentcerebrumhrms.models;

public class JSONResponse {

    private Data[] data;

    public Data[] getData() {
        return data;
    }

}
