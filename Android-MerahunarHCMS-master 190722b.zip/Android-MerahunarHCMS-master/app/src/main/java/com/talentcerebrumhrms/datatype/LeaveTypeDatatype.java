package com.talentcerebrumhrms.datatype;

/**
 * Created by saransh on 24-10-2016.
 */

public class LeaveTypeDatatype {

    private String type, id;

    public void setType(String type) {
        this.type = type;
    }

    public void setId(String no) {
        this.id = no;
    }

    public String getType() {
        return type;
    }

    public String getId() {
        return id;
    }
}
