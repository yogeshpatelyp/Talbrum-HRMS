package com.talentcerebrumhrms.fragment;

import androidx.fragment.app.Fragment;

/**
 * Created by Harshit on 06-Jul-17.
 */

public class ClosedInterviewFragment extends Fragment {
}
