package com.talentcerebrumhrms.utils;

/**
 * Created by saransh on 04-11-2016.
 */

public interface FragmentCallback {

    public void updateUI();
}
