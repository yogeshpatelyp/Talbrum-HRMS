package com.talentcerebrumhrms.utils;

import androidx.annotation.NonNull;

/**
 * Created by saransh on 15-11-2016.
 */

public interface SlidePanelListener {

    void slideUpPanelAction(@NonNull String name, @NonNull String phone, @NonNull String division, @NonNull String designation, @NonNull String email);

}
