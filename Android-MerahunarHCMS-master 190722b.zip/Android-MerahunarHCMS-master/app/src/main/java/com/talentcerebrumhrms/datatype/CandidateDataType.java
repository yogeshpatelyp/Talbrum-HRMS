package com.talentcerebrumhrms.datatype;

/**
 * Created by Harshit on 10-Jul-17.
 */

public class CandidateDataType {

    private String name, contact, email_id, tot_exp, prev_org, curr_loc, curr_ctc, age, pic;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getEmailId() {
        return email_id;
    }

    public void setEmailId(String email_id) {
        this.email_id = email_id;
    }

    public String getTotalExp() {
        return tot_exp;
    }

    public void setTotalExp(String tot_exp) {
        this.tot_exp = tot_exp;
    }

    public String getPrevOrg() {
        return prev_org;
    }

    public void setPrevOrg(String prev_org) {
        this.prev_org = prev_org;
    }

    public String getCurrLoc() {
        return curr_loc;
    }

    public void setCurrLoc(String curr_loc) {
        this.curr_loc = curr_loc;
    }

    public String getCurrCtc() {
        return curr_ctc;
    }

    public void setCurrCtc(String curr_ctc) {
        this.curr_ctc = curr_ctc;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }
}
